#include "parser.h"

#include <iostream>

using namespace std;




Parser::Parser(vector<Token> listaTokens)
{
    tokens = listaTokens;

    posicao = 0;
}



bool Parser::consumir(TipoToken esperado)
{
 
    if (posicao < tokens.size())
    {
    
        if (tokens[posicao].tipo == esperado)
        {
            posicao++;

            return true;
        }


   
        cout << endl;

        cout << "ERRO SINTATICO!" << endl;

        cout << "Esperado: "
             << nomeToken(esperado)
             << endl;

        cout << "Encontrado: "
             << tokens[posicao].valor
             << endl;

        return false;
    }


    cout << endl;

    cout << "ERRO SINTATICO!" << endl;

    cout << "Esperado: "
         << nomeToken(esperado)
         << endl;

    cout << "Encontrado: FIM DA ENTRADA"
         << endl;


    return false;
}


bool Parser::direcao()
{
 
    if (posicao >= tokens.size())
    {
        cout << "ERRO SINTATICO!" << endl;
        cout << "Esperado: DIREITA ou ESQUERDA"
             << endl;

        return false;
    }


   
    if (tokens[posicao].tipo == DIREITA)
    {
        posicao++;

        return true;
    }


  
    if (tokens[posicao].tipo == ESQUERDA)
    {
        posicao++;

        return true;
    }


    cout << endl;

    cout << "ERRO SINTATICO!" << endl;

    cout << "Esperado: DIREITA ou ESQUERDA"
         << endl;

    cout << "Encontrado: "
         << tokens[posicao].valor
         << endl;


    return false;
}




bool Parser::comando()
{

    if (posicao < tokens.size() &&
        tokens[posicao].tipo == ANDAR)
    {
        consumir(ANDAR);

        if (!consumir(NUMERO))
            return false;

        if (!consumir(PONTO_VIRGULA))
            return false;

        return true;
    }

        if (posicao < tokens.size() &&
        tokens[posicao].tipo == ESPERAR)
    {
        consumir(ESPERAR);

        if (!consumir(NUMERO))
            return false;

        if (!consumir(PONTO_VIRGULA))
            return false;

        return true;
    }

        if (posicao < tokens.size() &&
        tokens[posicao].tipo == PARAR)
    {
        consumir(PARAR);

        if (!consumir(PONTO_VIRGULA))
            return false;

        return true;
    }

        if (posicao < tokens.size() &&
        tokens[posicao].tipo == DESVIAR)
    {
        consumir(DESVIAR);

        if (!consumir(NUMERO))
            return false;

        if (!consumir(PONTO_VIRGULA))
            return false;

        return true;
    }

   

    if (posicao < tokens.size() &&
        tokens[posicao].tipo == VIRAR)
    {
        consumir(VIRAR);

        if (!direcao())
            return false;

        if (!consumir(PONTO_VIRGULA))
            return false;

        return true;
    }


    return false;
}




bool Parser::programa()
{
 
    if (!consumir(INICIO))
        return false;


  
    while (posicao < tokens.size() &&
          (tokens[posicao].tipo == ANDAR ||
           tokens[posicao].tipo == VIRAR||
           tokens[posicao].tipo == ESPERAR||
           tokens[posicao].tipo == PARAR||
           tokens[posicao].tipo == DESVIAR
        ))
    {
        if (!comando())
            return false;
    }


   
    if (!consumir(FIM))
        return false;


  
    if (posicao != tokens.size())
    {
        cout << endl;

        cout << "ERRO SINTATICO!" << endl;

        cout << "Existem tokens depois de 'fim'."
             << endl;

        return false;
    }


    return true;
}
