aula6: \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/Scrt1.o \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/crti.o \
  /usr/lib/gcc/x86_64-linux-gnu/15/crtbeginS.o \
  CMakeFiles/aula6.dir/aula6.cpp.o \
  CMakeFiles/aula6.dir/lexer.cpp.o \
  CMakeFiles/aula6.dir/parser.cpp.o \
  /usr/lib/gcc/x86_64-linux-gnu/15/libstdc++.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libm.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libm.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libm.so \
  /usr/lib/x86_64-linux-gnu/libm.so.6 \
  /usr/lib/x86_64-linux-gnu/libmvec.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libc.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libc.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libc.so \
  /usr/lib/x86_64-linux-gnu/libc.so.6 \
  /usr/lib/x86_64-linux-gnu/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/15/crtendS.o \
  /usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/crtn.o \
  /usr/lib/x86_64-linux-gnu/libm.so.6 \
  /lib64/ld-linux-x86-64.so.2

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/Scrt1.o:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/crti.o:

/usr/lib/gcc/x86_64-linux-gnu/15/crtbeginS.o:

CMakeFiles/aula6.dir/aula6.cpp.o:

CMakeFiles/aula6.dir/lexer.cpp.o:

CMakeFiles/aula6.dir/parser.cpp.o:

/usr/lib/gcc/x86_64-linux-gnu/15/libstdc++.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libm.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libm.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libm.so:

/usr/lib/x86_64-linux-gnu/libm.so.6:

/usr/lib/x86_64-linux-gnu/libmvec.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libc.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libc.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libc.so:

/usr/lib/x86_64-linux-gnu/libc.so.6:

/usr/lib/x86_64-linux-gnu/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/15/crtendS.o:

/usr/lib/gcc/x86_64-linux-gnu/15/../../../x86_64-linux-gnu/crtn.o:

/usr/lib/x86_64-linux-gnu/libm.so.6:

/lib64/ld-linux-x86-64.so.2:
