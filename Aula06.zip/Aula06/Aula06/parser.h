#ifndef PARSER_H
#define PARSER_H

#include "lexer.h"

#include <vector>

using namespace std;




class Parser
{
private:


    vector<Token> tokens;


    int posicao;


  
    bool consumir(TipoToken esperado);




    bool comando();

    bool direcao();


public:

  
    Parser(vector<Token> listaTokens);



    bool programa();
};


#endif
